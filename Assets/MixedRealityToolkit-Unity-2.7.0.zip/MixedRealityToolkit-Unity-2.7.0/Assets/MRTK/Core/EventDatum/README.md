# Mixed Reality Toolkit - EventDatum

Data model classes for the inner workings of the Mixed Reality Toolkit and its supported Core systems.

All data models required for system use within the MRTK should be recorded here.
